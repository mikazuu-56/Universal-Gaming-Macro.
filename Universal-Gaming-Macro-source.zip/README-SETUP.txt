Universal Gaming Macro — Prototype 0.1.0

Isi ZIP ini adalah source project Android. Project ini berupa editor dan pratinjau urutan langkah lokal; belum mengirim sentuhan ke game atau menyediakan overlay.

Cara singkat:
1. Ekstrak ZIP ke root repository GitHub (bukan upload ZIP sebagai arsip saja).
2. Tambahkan workflow GitHub Actions pada .github/workflows/android.yml.
3. Jalankan Actions > Android Debug APK > Run workflow.
4. Setelah selesai, unduh artifact Universal-Gaming-Macro-debug.

Workflow yang perlu dibuat:
Lihat file android.yml yang disertakan di dalam folder .github/workflows/.

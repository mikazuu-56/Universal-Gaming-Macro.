package com.mikazuu.universalgamingmacro

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val steps = mutableListOf<String>()
    private lateinit var stepList: TextView
    private lateinit var delayInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderScreen()
    }

    private fun renderScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }

        val title = TextView(this).apply {
            text = "Universal Gaming Macro"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF172033.toInt())
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "Macro sequence editor • Prototype 0.1.0"
            textSize = 14f
            setPadding(0, 8, 0, 20)
        }
        page.addView(subtitle)

        page.addView(TextView(this).apply { text = "Jeda antar langkah (ms)" })

        delayInput = EditText(this).apply {
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("100")
            hint = "Contoh: 100"
        }
        page.addView(delayInput, matchWidth())

        page.addView(Button(this).apply {
            text = "Tambah langkah contoh"
            setOnClickListener {
                steps.add("Langkah ${steps.size + 1}")
                refreshSteps()
            }
        }, matchWidth())

        stepList = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFF263247.toInt())
            setPadding(12, 16, 12, 16)
            text = "Belum ada langkah. Tambahkan langkah untuk mulai menyusun urutan."
        }
        page.addView(stepList, matchWidth())

        page.addView(Button(this).apply {
            text = "Pratinjau urutan"
            setOnClickListener {
                val delay = delayInput.text.toString().toLongOrNull()
                if (delay == null || delay < 1) {
                    Toast.makeText(this@MainActivity, "Masukkan jeda minimal 1 ms", Toast.LENGTH_SHORT).show()
                } else if (steps.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Tambahkan langkah terlebih dahulu", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "${steps.size} langkah • jeda ${delay} ms", Toast.LENGTH_LONG).show()
                }
            }
        }, matchWidth())

        page.addView(Button(this).apply {
            text = "Hapus semua langkah"
            setOnClickListener {
                steps.clear()
                refreshSteps()
            }
        }, matchWidth())

        page.addView(TextView(this).apply {
            text = "Catatan: versi ini adalah editor/pratinjau lokal. Belum mengirim input sentuhan ke game atau membuat tombol overlay."
            textSize = 12f
            setPadding(0, 20, 0, 0)
        }, matchWidth())

        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun refreshSteps() {
        stepList.text = if (steps.isEmpty()) {
            "Belum ada langkah. Tambahkan langkah untuk mulai menyusun urutan."
        } else {
            steps.mapIndexed { index, value -> "${index + 1}. $value" }.joinToString("\n")
        }
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 8 }
}
